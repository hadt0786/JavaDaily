public class PointTest
{
    public static void main(String[] args)
    {
	Point p1 = new Point(2, 3);

	Point p2 = new Point(5, 7);

	System.out.println(p1.distanceTo(p2));


	Point3D p3 = new Point3D(1, 2, 3);
	
	Point3D p4 = new Point3D(4, 6, 15);

	System.out.println(p3.distanceTo(p4));

    }
}