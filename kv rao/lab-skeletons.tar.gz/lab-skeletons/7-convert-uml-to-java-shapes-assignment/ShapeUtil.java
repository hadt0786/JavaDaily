public class ShapeUtil{

    public static void areaPrinter(Shape shapes[]){
	// Write code using supertype (Shape)
	for (int i=0; i<shapes.length; i++)
	    System.out.println("Shape " + i + " is a " + 
			       shapes[i].getName() +
			       " and has area " + shapes[i].getArea());
    }


    public static void volumePrinter(Shape3D shapes3D[]){
	for (int i=0; i<shapes3D.length; i++) {
	    System.out.println("Three dimensional shape " + i + 
			       " has volume " +
			       shapes3D[i].getVolume());
	}
    }


    public static void cornersPrinter(VerticesCountable shapes[]){
	for (int i=0; i<shapes.length; i++){
	    System.out.println("Shape " + i + " has " + 
			       shapes[i].countVertices() + 
			       " vertices ");
	    
	    if (shapes[i] instanceof Shape2D){
		Shape2D r = (Shape2D) shapes[i];
		System.out.println(r.getCircumference());
	    }
	}


    }

}
