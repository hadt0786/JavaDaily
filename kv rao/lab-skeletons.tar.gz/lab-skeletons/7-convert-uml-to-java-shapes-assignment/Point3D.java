public class Point3D extends Point{

    private double z;

    public Point3D(double x, double y, double z) {
	super(x,y);
	this.z = z;
    }

    public double getZ(){
	return z;
    }

    public double distanceTo(Point3D p)
    {
	return Math.sqrt(Math.pow(x-p.getX(), 2.0) + Math.pow(y-p.getY(), 2.0) + Math.pow(z-p.getZ(), 2.0) );
    }
}
