public class ShapeTest{

    public static void main(String args[]){
	
	Shape myShapes[] = new Shape[4];

	Point3D p3D = new Point3D(1,1,1);
	myShapes[0] = new Sphere(p3D, 1);

	Point p1 = new Point(2,2);
	Point p2 = new Point(4,2);
	Point p3 = new Point(4,4);
	Point p4 = new Point(2,4);
	myShapes[1] = new Rectangle(p1, p2, p3, p4);
	
	myShapes[2] = new Circle(p1, 1);

	Point3D[] pCube = new Point3D[8];
	pCube[0] = new Point3D(0, 0, 0);
	pCube[1] = new Point3D(0, 0, 1);
	pCube[2] = new Point3D(0, 1, 0);
	pCube[3] = new Point3D(1, 0, 0);
	pCube[4] = new Point3D(0, 1, 1);
	pCube[5] = new Point3D(1, 1, 0);
	pCube[6] = new Point3D(1, 0, 1);
	pCube[7] = new Point3D(1, 1, 1);
	myShapes[3] = new Cube(pCube);

	ShapeUtil.areaPrinter(myShapes);

	Shape3D otherShapes[] = new Shape3D[2];
	otherShapes[0] = (Sphere) myShapes[0];
	otherShapes[1] = (Cube) myShapes[3];
	ShapeUtil.volumePrinter(otherShapes);

	VerticesCountable shapeWithVertices = (Rectangle)myShapes[1];

	VerticesCountable[] shapesWithVertices = new VerticesCountable[2];
	shapesWithVertices[0] = shapeWithVertices;
	shapesWithVertices[1] = (Cube)myShapes[3];

	ShapeUtil.cornersPrinter(shapesWithVertices);
    }
}
