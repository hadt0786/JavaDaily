/*
 * In Java, Objects are passed by reference, and primitives are passed by value. 
 * This is half incorrect. 
 * Everyone can easily agree that primitives are passed by value; 
 * there's no such thing in Java as a pointer/reference to a primitive. 
 * However, Objects are not passed by reference. 
 * A correct statement would be "Object references are passed by value".
 */

public class JavaValueReference {

    public static void main(String[] args) 
    {
	int a = 2, b = 3;

	System.out.println("Before badswap: a = " + a + ", b = " + b);

	badSwap(a, b);

	System.out.println("After badswap: a = " + a + ", b = " + b);  // Same Value !!
	System.out.println();


	Point p = new Point(1, 2);
	System.out.println("Initial point: " + p);

	pass1(p, 5);
	System.out.println("After pass1: " + p);// It is changed

	pass2(p, 5); 
	System.out.println("After pass2: " + p);// It is not changed
	System.out.println();
	

	Point p1 = new Point(0,0);
	Point p2 = new Point(1,1);

	System.out.println("Initial p1: " + p1); 
	System.out.println("Initial p2: " + p2);
	System.out.println();

	pass3(p1,p2);

	System.out.println("p1 after pass3: " + p1); // It is changed
	System.out.println("p2 after pass3: " + p2); // It is not changed
    }

    public static void badSwap(int var1, int var2)
    {
	int temp = var1;
	var1 = var2;
	var2 = temp;
    }

    public static void pass1(Point argp, int len)
    {
	argp.translate(len);
    }

    // changes to p remain inside because p is a reference copy.
    public static void pass2(Point argp, int len)
    {
	Point p1 = new Point(10, 10);
	p1.translate(5);
	argp = p1;
    }

    public static void pass3(Point argp1, Point argp2)
    {
	argp1.x = 100;
	argp1.y = 100;
	Point temp = argp1;
	argp1 = argp2;
	argp2 = temp;
    }
}

class Point
{
    protected int x, y;

    public Point(int x, int y)
    {
	this.x = x;
	this.y = y;
    }

    public void translate(int len)
    {
	x = x + len;
	y = y + len;
    }

    public String toString()
    {
	return "(" + x + ", " + y + ")";
    }
}
