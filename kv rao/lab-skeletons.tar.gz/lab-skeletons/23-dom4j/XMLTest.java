import java.io.FileWriter;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
//import org.dom4j.dom.DOMDocumentFactory;
//import org.dom4j.dom.DOMDocument;
import java.util.List;

/**
 *
 * @author onur
 */
public class XMLTest 
{
    Element modelRoot; // root
    
    /** Creates a new instance of FileManager */
    public XMLTest() {
    }
    
    public static void main(String[] args)
    {
	Document document = DocumentHelper.createDocument();
	Element projectRoot = document.addElement( "Automata");
        Element automataRoot = projectRoot.addElement( "Automaton").addAttribute("name", "test");
        
        Element eventsElement = automataRoot.addElement("Events");
        
	String[] events = {"e0", "e1", "e2"};
	
	Element modelElement = null;
	for(int i = 0; i<events.length; i++)
            {
                modelElement = eventsElement.addElement("Event");
                modelElement.addAttribute("id",  events[i] );
            }

        
        // lets write to a file
        try
        {
            XMLWriter writer = new XMLWriter( new FileWriter("test1.xml") );
            writer.write( document );
            writer.close();
        }
        catch(Exception e)
        {
            System.out.println("exception");
        }

	Element newElement = (Element)modelElement.clone(); 
	newElement.addAttribute("id", "e3");
	List eventsList = eventsElement.content();
	eventsList.add(3, newElement);
	
	
	// lets write to a file
        try
        {
            XMLWriter writer = new XMLWriter( new FileWriter("test2.xml") );
            writer.write( document );
            writer.close();
        }
        catch(Exception e)
        {
            System.out.println("exception");
        }

    }
}