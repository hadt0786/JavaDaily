/**
 *
 * @author onur
 */
public class StackTest 
{    
    /** Creates a new instance of StackTest */
    public StackTest() {
    }
    
    public static void main(String[] args)
    {
        String[] prefixStrings = {"/-ab*c+de", "a", "+ab", "/a+b*c-de", "-/+*abcde"};

	for(int i = 0; i < prefixStrings.length; i++)
	    {
		System.out.println(prefixStrings[i] + "  " + PrefixToInfixConverter.convert(prefixStrings[i]));
	    }
    }
}
