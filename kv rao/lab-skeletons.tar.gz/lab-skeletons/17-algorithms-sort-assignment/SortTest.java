import java.util.*;

class SortTest {
    private Vector list = new Vector();

    public SortTest() {
	list.addElement(new Person("John", 20, 1.80));
	list.addElement(new Person("Jane", 30, 1.75));
	list.addElement(new Person("Michael", 25, 1.85));
    }

    public void sortAge() {
	Comparator ageComparator = new AgeComparator();
	Collections.sort(list, ageComparator);
    }

    public void sortHeight() {
	Comparator heightComparator = new HeightComparator();
	Collections.sort(list, heightComparator);
    }

    public void print() {
	System.out.println(list);
    }

    public static void main(String [] args) 
    {
	SortTest s = new SortTest();
	
	System.out.println("Sorted acc. to age:");
	s.sortAge();
	s.print();
	
	System.out.println("Sorted acc. to height:");
	s.sortHeight();
	s.print();
    }
}