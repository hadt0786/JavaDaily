import java.util.Enumeration;

public class SortedVectorTest {
	public SortedVectorTest() {}
	public static void main(String[] args) {
		
		SortedCollection sv = new SortedVector();  
		sv.addSorted("g");
		sv.addSorted("k");
		sv.addSorted("b");
		sv.addSorted("c");
		sv.addSorted("l");
		sv.addSorted("b");
		sv.addSorted("a");
		sv.addSorted("z");
		sv.addSorted("s");

		for (Enumeration e=sv.elements();e.hasMoreElements();)
			System.out.println(e.nextElement());
	}
}
