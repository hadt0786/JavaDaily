
public class Person
{
    public enum Type {GUARDIAN, PRISONER};

    private String name;
    
    private Type type;

    public Person(String name, Type type)
    {
	this.name = name;
	this.type = type;
    }

    public String getName()
    {
	return name;
    }

    public Type getType()
    {
	return type;
    }
}
