
public class UnauthorizedKeyAccessException extends Exception
{
    private Person p;

    public UnauthorizedKeyAccessException(Person p)
    {
	this.p = p;
    }

    public Person getPerson()
    {
	return p;
    }
}