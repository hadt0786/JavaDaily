

public class Prisoner extends Person
{
    Guardian roomGuardian;

    public Prisoner(String name, Guardian roomGuardian)
    {
	super(name, Person.Type.PRISONER);
	this.roomGuardian = roomGuardian;
    }

    public Guardian getRoomGuardian()
    {
	return roomGuardian;
    }
}
