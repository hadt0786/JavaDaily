
// dummy Key class

public class Key
{
    private String k;

    public Key(String k)
    {
	this.k = k;
    }
    
    public String getKey()
    {
	return k;
    }
}