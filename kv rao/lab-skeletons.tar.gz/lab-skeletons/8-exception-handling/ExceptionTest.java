
public class ExceptionTest
{
    public static void main(String[] args)
    {
	// Prisoner and Guardian extends Person
	Guardian guardian = new Guardian("James Ford");
	Prisoner prisoner = new Prisoner("John Doe", guardian);
	try{
	    prisoner.getRoomGuardian().getRoomKey(prisoner);
	} catch(UnauthorizedKeyAccessException ex)
	    {
		// handle the exception
	    }
    }

}