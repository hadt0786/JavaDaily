

public class Guardian extends Person
{
    private Key roomKey;

    public Guardian(String name)
    {
	super(name, Person.Type.GUARDIAN);
	roomKey = new Key("The key");
    }

    public Key getRoomKey(Person requester)
    {
	// if the requester is of type GUARDIAN return the room key, otherwise throw an exception (UnauthorizedKeyAccessException)
    }
}
