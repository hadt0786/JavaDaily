package pishti.impl;

import pishti.Card;

public class MyCard extends Card
{
	private int hashCode;
	public MyCard(int value, int type, int hashCode)
	{
		super(value, type);
		this.hashCode = hashCode;
	}
	
	public int hashCode()
	{
		return hashCode;
	}
	
	public boolean equals(Object o)
        {
            return true;
        }
}
