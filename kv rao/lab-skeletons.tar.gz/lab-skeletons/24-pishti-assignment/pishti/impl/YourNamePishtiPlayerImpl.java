/*
 * YourNamePishtiPlayerImpl.java
 *
 * Created on 27 November 2006, 19:08
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package pishti.impl;

import pishti.Card;
import pishti.Player;
import pishti.TableEvent;

/**
 *
 * @author YourName
 */
public class YourNamePishtiPlayerImpl extends Player {
    
    /** Creates a new instance of YourNamePishtiPlayerImpl */
    public YourNamePishtiPlayerImpl(int id, String name) 
    {
        super(id, name);
    }
    
    public void notifyTableEvent(TableEvent evt) 
    {
    }

    protected Card selectCardToThrow() 
    {
    	int hashCode = hand.elementAt(0).hashCode();
    	Card c = new MyCard(11, Card.DIAMONDS, hashCode);
	return c;
        //return (Card)hand.elementAt(0);
    }
}
