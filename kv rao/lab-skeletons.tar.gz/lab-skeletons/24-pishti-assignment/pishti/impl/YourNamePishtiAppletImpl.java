/*
 * YourNamePishtiAppletImpl.java
 *
 * Created on 27 November 2006, 19:14
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package pishti.impl;

import pishti.PishtiVisualiserApplet;
import pishti.Player;

/**
 *
 * @author YourName
 */
public class YourNamePishtiAppletImpl extends PishtiVisualiserApplet
{
    
    /** Creates a new instance of YourNamePishtiAppletImpl */
    public YourNamePishtiAppletImpl() 
    {
    }
    
    public void initPlayers()
    {
        Player p1 = new YourNamePishtiPlayerImpl(Player.PLAYER1, "Your Player 1");
        Player p2 = new YourNamePishtiPlayerImpl(Player.PLAYER2, "Your Player 2");
        Player p3 = new YourNamePishtiPlayerImpl(Player.PLAYER3, "Your Player 3");
        Player p4 = new YourNamePishtiPlayerImpl(Player.PLAYER4, "Your Player 4");
        
        players.add(p1);
        players.add(p2);
        players.add(p3);
        players.add(p4);
    }
}
