import java.io.*;

public class PipeTest {
    
    public PipeTest() 
    {
    }

    
    public static void main(String [] args) throws IOException 
    {
        PipedWriter pw = new PipedWriter();
        PipedReader pr = new PipedReader(pw);
        
        SourceThread src = new SourceThread("source", pw);
        DestinationThread dest = new DestinationThread("destination", pr);
        
        src.start();
	dest.start();
    }
    
}

class SourceThread extends Thread
{
  private PipedWriter pw;

  SourceThread(String name, PipedWriter pw)
  {
    super (name);
    this.pw = pw;
  }

  public void run ()
  {
   try
   {
       for (int i = 0; i < 150; i++)
         pw.write (i + "\n");

       pw.close ();
   }
   catch (IOException e)
   {
   }
  }
}

class DestinationThread extends Thread {
    private PipedReader pr;
    
    DestinationThread(String name, PipedReader pr) {
        super(name);
        this.pr = pr;
    }
    
    public void run() {
        try {
            int item;
            while ((item = pr.read()) != -1)
                System.out.print((char) item);    // dst reads
            
            pr.close();
        } catch (IOException e) {
        }
    }
}