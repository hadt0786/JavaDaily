/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author onur
 */
public class CalculatorLogicTest
{

    CalculatorLogic instance = null;
    JTextField display = null;

    public CalculatorLogicTest()
    {
    }

    @BeforeClass
    public static void setUpClass() throws Exception
    {
    }

    @AfterClass
    public static void tearDownClass() throws Exception
    {
    }

    @Before
    public void setUp()
    {
        display = new JTextField();
        instance = new CalculatorLogic(display);
    }

    @After
    public void tearDown()
    {
    }

    /**
     * Test of actionPerformed method, of class CalculatorLogic.
     */
    @Test
    public void testActionPerformed()
    {
        //System.out.println("actionPerformed");
        String[] sequence =
        {
            "10-4=+3=", "14-4x5=", "14-4=5x6="
        };
        String[] correctResult =
        {
            "9", "50", "30"
        };

        for (int i = 0; i < sequence.length; i++)
        {
            testSequence(sequence[i]);
            assertEquals(display.getText(), correctResult[i]);
        }

    // TODO review the generated test code and remove the default call to fail.
    //fail("The test case is a prototype.");
    }

    /*
     * functional test
     */
    @Test
    public void ftestNumbers()
    {
        //System.out.println("actionPerformed");
        String[] sequence =
        {
            "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"
        };
        String[] correctResult =
        {
            "1", "12", "123", "1234", "12345", "123456", "1234567", "12345678", "123456789", "1234567890"
        };

        for (int i = 0; i < sequence.length; i++)
        {
            testSequence(sequence[i]);
            assertEquals(display.getText(), correctResult[i]);
        }
    }

    /*
     * user-friendliness test
     */
    @Test
    public void uftestOperators()
    {
        //System.out.println("actionPerformed");
        String[] sequence =
        {
            "1234+"//, "2345-", "3456x", "6789/", "89="
        };
        String[] correctResult =
        {
            "1234+"//, "2345-", "3456x", "6789/", "89"
        };

        for (int i = 0; i < sequence.length; i++)
        {
            testSequence(sequence[i]);
            assertEquals(display.getText(), correctResult[i]);
        }
    }
    
    @Test
    public void uftestOperators2()
    {
        //System.out.println("actionPerformed");
        String[] sequence =
        {
            "1234+6789"//, "2345-", "3456x", "6789/", "89="
        };
        String[] correctResult =
        {
            "1234+6789"//, "2345-", "3456x", "6789/", "89"
        };

        for (int i = 0; i < sequence.length; i++)
        {
            testSequence(sequence[i]);
            assertEquals(display.getText(), correctResult[i]);
        }
    }

    @Test
    public void ftestOperators()
    {
        //System.out.println("actionPerformed");
        String[] sequence =
        {
            "1234+2345="//, "2345-1234=", "3456x4567=", "6789/3=", "9=1"
        };
        String[] correctResult =
        {
            "3579"//, "1111", "15783552", "2263", "1"
        };

        for (int i = 0; i < sequence.length; i++)
        {
            testSequence(sequence[i]);
            assertEquals(display.getText(), correctResult[i]);
        }
    }
    
    @Test
    public void uftestOperatorAfterOperator()
    {
        //System.out.println("actionPerformed");
        String[] sequence =
        {
            "1234+2345/"//, "2345-1234*", "3456x4567+", "6789/3-"
        };
        String[] correctResult =
        {
            "3579/"//, "1111*", "15783552+", "2263-"
        };

        for (int i = 0; i < sequence.length; i++)
        {
            testSequence(sequence[i]);
            assertEquals(display.getText(), correctResult[i]);
        }
    }

    @Test
    public void ftestOperatorAfterOperator()
    {
        //System.out.println("actionPerformed");
        String[] sequence =
        {
            "1+2+3="//, "14-4=5x6=", "10-4=+3="
        };
        String[] correctResult =
        {
            "6"//, "30", "9"
        };

        for (int i = 0; i < sequence.length; i++)
        {
            testSequence(sequence[i]);
            assertEquals(display.getText(), correctResult[i]);
        }
    }
    
    @Test
    public void ftestSecondOperatorOverrides()
    {
        //System.out.println("actionPerformed");
        String[] sequence =
        {
            "3+x5="
        };
        String[] correctResult =
        {
            "15"
        };

        for (int i = 0; i < sequence.length; i++)
        {
            testSequence(sequence[i]);
            assertEquals(display.getText(), correctResult[i]);
        }
    }

    // TODO: more tests long number like 999999999999999999999, numbers starting with zeros like 00000000023, divide by zero test. missing '3+4=5+6=' -> 11
    
    private void testSequence(String sequence)
    {
        for (int i = 0; i < sequence.length(); i++)
        {
            ActionEvent e = new ActionEvent(this, i, sequence.substring(i, i + 1));
            instance.actionPerformed(e);
        }
    }
}