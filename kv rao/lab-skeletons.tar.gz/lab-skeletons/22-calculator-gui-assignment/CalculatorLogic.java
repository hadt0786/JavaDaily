/**
 * Modify this file in order to implement the functionalities 
 * of the calculator
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;

public class CalculatorLogic implements ActionListener
{

    protected JTextField jTextFieldDisplay;

    public CalculatorLogic(JTextField display)
    {
        jTextFieldDisplay = display;
        jTextFieldDisplay.setText("0");
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        String inStr = e.getActionCommand();
	System.out.println(inStr);
    }


}
