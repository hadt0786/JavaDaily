import java.util.Enumeration;

class HashtableAdapterTest 
{
    public static void main(String[] args) 
    {
	OrderedHashtable oh = new HashtableAdapter();
	oh.put("January", "1st month");
	oh.put("February", "2nd month");
	oh.put("March", "3rd month");
	oh.put("April", "4th month");
	oh.put("May", "5th month");
	oh.put("June", "6th month");
	oh.put("July", "7th month");
	oh.put("August", "8th month");
	oh.put("September", "9th month");
	oh.put("October", "10th month");
	oh.put("November", "11th month");
	oh.put("December", "12th month");
	
	for (Enumeration r = oh.keysInPutOrder(); r.hasMoreElements();) 
	    {
		Object k = r.nextElement();
		System.out.println(k + " is the " + oh.get(k) );
	    }
    }
}
