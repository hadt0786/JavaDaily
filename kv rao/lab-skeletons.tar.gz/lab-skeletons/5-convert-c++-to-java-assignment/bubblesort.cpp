#include <iostream>
using namespace std;

void printArray(int* x, int len)
{
  for(int i=0; i<len; i++)
    {
      cout << x[i] << " ";
    }
}

void swap(int *i, int *j) {
  int t = *i;
  *i = *j;
  *j = t;
}

void bubbleSort(int* list, int len, int& numSwaps)
{
  for(int j=len-1; j>0; j--)
    {
      for(int i=0; i<j; i++)
	{
	  if(list[i] > list[i+1])
	    {
	      numSwaps++;
	      swap(&list[i], &list[i+1]);
	    }
	}
    }
}

int main()
{
  int list[16] = {3, 5, 2, 6, 6, 5, 3, 3, 3, 3, 7, 3, 9, 1, 1, 1};
  int len = 16;
  
  cout << "Initial array:" << endl;
  
  printArray(list, len);
  
  cout << endl << "Number of elements: " << len << endl;
  
  int numSwaps = 0;
  bubbleSort(list, len, numSwaps);
  
  cout << "Done with sort." << endl;
  
  cout << "Ordered array:" << endl;
  
  printArray(list, len);
  
  cout << endl << "Number of swaps = " << numSwaps << endl;
  
  return 0;
}
