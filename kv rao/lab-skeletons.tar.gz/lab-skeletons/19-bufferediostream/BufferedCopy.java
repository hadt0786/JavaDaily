import java.io.*;

class BufferedCopy
{
  public static void main (String [] args)
  {
   if (args.length != 2)
   {
     System.out.println ("usage: java BufferedCopy srcpath dstpath");
     return;
   }

   BufferedInputStream bis = null;
   BufferedOutputStream bos = null;

   try
   {
     FileInputStream fis = new FileInputStream (args [0]);
     bis = new BufferedInputStream (fis);

     FileOutputStream fos = new FileOutputStream (args [1]);
     bos = new BufferedOutputStream (fos);

     int byte_;
     while ((byte_ = bis.read ()) != -1)
       bos.write (byte_);
   }
   catch (FileNotFoundException e)
   {
     System.out.println ("File not found");
     // Do other stuff related to that exception (if necessary).
   }
   catch (IOException e)
   {
     System.out.println ("I/O Problem: " + e.getMessage ());
     // Do other stuff related to that exception (if necessary).
   }
   finally
   {
     if (bis != null)
       try
       {
         bis.close ();
       }
       catch (IOException e)
       {
       }

     if (bos != null)
       try
       {
         bos.close ();
       }
       catch (IOException e)
       {
       }
   }
  }
}