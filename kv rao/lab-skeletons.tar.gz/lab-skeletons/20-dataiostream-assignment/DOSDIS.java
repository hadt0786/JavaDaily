import java.io.*;

public class DOSDIS
{
  public static void main (String [] args)
  {

     FileOutputStream fos = new FileOutputStream ("data.txt");
     // fill to write int, float, String in the file

     FileInputStream fis = new FileInputStream ("data.txt");
     // fill to read int, float, String from the file

  }
}