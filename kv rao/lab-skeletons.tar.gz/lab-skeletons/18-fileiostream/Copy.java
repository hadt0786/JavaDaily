import java.io.*;

class Copy
{
  public static void main (String [] args)
  {
   if (args.length != 2)
   {
     System.out.println ("usage: java Copy srcpath dstpath");
     return;
   }

   FileInputStream fis = null;
   FileOutputStream fos = null;

   try
   {
     fis = new FileInputStream (args [0]);
     fos = new FileOutputStream (args [1]);

     int byte_;
     while ((byte_ = fis.read ()) != -1)
       fos.write (byte_);
   }
   catch (FileNotFoundException e)
   {
     System.out.println ("File not found");
     // Do other stuff related to that exception (if necessary).
   }
   catch (IOException e)
   {
     System.out.println ("I/O Problem: " + e.getMessage ());
     // Do other stuff related to that exception (if necessary).
   }
   finally
   {
     if (fis != null)
       try
       {
         fis.close ();
       }
       catch (IOException e)
       {
       }

     if (fos != null)
       try
       {
         fos.close ();
       }
       catch (IOException e)
       {
       }
   }
  }
}
