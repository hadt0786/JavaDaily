public class SwapWithMyInteger {

    static void swap(MyInteger i, MyInteger j) {
	// fill this part
    }

    public static void main(String[] args) {
	MyInteger a = new MyInteger(5);
	MyInteger b = new MyInteger(7);
	
	System.out.println("Before swap: a: " + a + "\t b: " + b);
	swap(a, b);
	System.out.println("After swap: a: " + a + "\t b: " + b);
    }
}

class MyInteger
{
    // fill this part
}
