import java.util.Enumeration;
import java.util.Hashtable;

public class Dictionary {

    // fill

    public Dictionary()
    { 
	// fill
    }

    public void addWord(String word, String definition)
    {
	// fill
    }

    public Object getDefinition(String word)
    {
	// fill
    }

    public void printAllWords()
    {
	// fill
    }

    public static void main(String[] args) 
    {
	Dictionary myDictionary=new Dictionary();
	myDictionary.addWord("java", "kind of coffee grown on Java and nearby islands of modern Indonesia.");
	myDictionary.addWord("Sun", "the star that is the central body of the solar system");
	
	System.out.println("java:" + myDictionary.getDefinition("java"));
	
	System.out.println("List of words:");
	myDictionary.printAllWords();		
    }
    
}
