public class SwapWithArray {
    // swap elements inside the array with indices i and j
    static void swap(int[] a, int i, int j) {
	// fill this function
    }

    static void printArray(int[] a) {
	for (int i = 0; i < a.length; i++) {
	    if (i%4 == 0) System.out.println();
	    System.out.print(a[i] + " \t");
	}
	System.out.println();
    }

    public static void main(String[] args) {
	int size = 2;
	int[] r = new int[size];
	for (int i = 0; i < size; i++)
	    r[i] = (int)(Math.random()*size*10 + 1);
	System.out.println("Before swap:");
	printArray(r);
	swap(r, 0, 1);
	System.out.println("After swap:");
	printArray(r);
    }
}
